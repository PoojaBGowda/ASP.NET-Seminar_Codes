﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataBound
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                String Connectionstr = "server=INCHCMPC11330;database=Northwind";
                SqlConnection con = new SqlConnection(Connectionstr);
                String Query = "select * from Employees";
                try
                {
                    con.Open();
                    SqlCommand command = new SqlCommand(Query, con);
                    SqlDataReader reader = command.ExecuteReader();
                    GridView1.DataSource = reader;//Providing datasource
                    GridView1.DataBind();//Binding data
                }
                catch (Exception ex)
                {
                     MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}