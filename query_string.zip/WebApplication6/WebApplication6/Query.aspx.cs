﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Query : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string firstname = Request.QueryString["FirstName"];
        string lastname = Request.QueryString["LastName"];
        Label3.Text = "FirstName " + firstname + " " + lastname;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        Response.Redirect("default2.aspx?firstname=" + TextBox1.Text + "&lastname=" + TextBox2.Text);

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}