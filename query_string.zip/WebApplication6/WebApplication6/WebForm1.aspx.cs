﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string firstname = Request.QueryString["FirstName"];
            string lastname = Request.QueryString["LastName"];
            Label1.Text = "FirstName " + firstname + " " + lastname;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("default2.aspx ? firstname = " + TextBox1.Text + " & lastname = " + TextBox2.Text);
        }
    }
}