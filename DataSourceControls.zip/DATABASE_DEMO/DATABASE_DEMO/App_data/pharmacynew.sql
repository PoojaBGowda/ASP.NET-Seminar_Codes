create table signup
(firstname varchar(50) not null,
lastname varchar(50),
gender char(10),
password varchar(15) not null,
emailid varchar(50),
userid varchar(50) primary key not null)

CREATE table admin
(userid varchar(50) references signup(userid),
password varchar(15) not null)

create table login
(userid varchar(50) references signup(userid),
password varchar(15) not null)

insert into admin values('mouni','123456');

create table intimatestock
(MedicineName varchar(20) not null,
Quantity float not null,
DeliveryDate date)

create table salesreport
(MedicineName varchar(20) not null,
Quantity float not null,
Price money)values(
 
create table stock
(MedicineName varchar(20) not null) values(crocin,cipla);