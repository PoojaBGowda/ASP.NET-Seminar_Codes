﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace DATABASE_DEMO
{
    public class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
    }
    public class CategoryDataAccessLayer
    {
        public static List<Category> GetAllProducts()
        {
            List<Category> ListProducts = new List<Category>();
            string CS = ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("select * from categories", con);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Category cat = new Category();
                    cat.CategoryId = Convert.ToInt32(rdr["CategoryId"]);
                    cat.CategoryName = rdr["CategoryName"].ToString();
                    cat.Description = rdr["Description"].ToString();
                    ListProducts.Add(cat);
                }
            }
            return ListProducts;
        } }
            
            
        }

