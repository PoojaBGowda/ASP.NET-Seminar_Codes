﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace DataSource
{
    public class category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
    }
    public class CategoryDataAccess
    {
        List<category> ListCategory = new List<category>();
        string ds = ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString;
        using(SqlConnection con=new SqlConnection(ds))
    {


    }

}