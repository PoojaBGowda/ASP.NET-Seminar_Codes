﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication7
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
             // PlaceHolder1.Controls.Add(LoadControl("WebUserControl2.ascx"));
            WebUserControl2 wc1 = (WebUserControl2)LoadControl("WebUserControl2.ascx");
            wc1.ID = "wc2";
            PlaceHolder1.Controls.Add(wc1);
        }
    }
}